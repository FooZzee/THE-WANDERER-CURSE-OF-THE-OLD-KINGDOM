import {
  calculateMerchantPrice,
  enforceExclusiveEquipment,
  getItemEquipSlot,
  getUpgradeCost,
} from './rules';
import type { EquipmentSlot, GameItem, PlayerStats, SkillNode } from './types';

export class InventorySystem {
  public items: GameItem[] = [];
  public shopCatalog: GameItem[] = [];
  public skills: SkillNode[] = [];

  constructor() {
    this.initStartingInventory();
    this.initShopCatalog();
    this.initSkillTree();
  }

  public initStartingInventory(): void {
    this.items = [
      {
        id: 'sword_wolf_steel',
        name: 'Стальной меч Школы Странника',
        description: 'Надёжный клинок из кованой стали для боя с людьми и дикими зверями.',
        category: 'weapon',
        equipSlot: 'steelSword',
        rarity: 'uncommon',
        value: 90,
        quantity: 1,
        equipped: true,
        upgradeLevel: 0,
        stats: { attack: 14 },
      },
      {
        id: 'sword_runic_silver',
        name: 'Рунный серебряный меч',
        description: 'Серебряный клинок с гравировкой древних рун, смертоносный для чудовищ.',
        category: 'weapon',
        equipSlot: 'silverSword',
        rarity: 'rare',
        value: 140,
        quantity: 1,
        equipped: true,
        upgradeLevel: 0,
        stats: { silverAttack: 22 },
      },
      {
        id: 'armor_kaer_leather',
        name: 'Потёртая кожаная куртка охотника',
        description: 'Дорожная броня с кольчужными наплечниками, не сковывающая движений.',
        category: 'armor',
        equipSlot: 'armor',
        rarity: 'common',
        value: 80,
        quantity: 1,
        equipped: true,
        upgradeLevel: 0,
        stats: { defense: 8, maxHealth: 20 },
      },
      {
        id: 'potion_swallow',
        name: 'Эликсир «Ласточка»',
        description: 'Восстанавливает 65 ед. здоровья (+20 Токсичности).',
        category: 'potion',
        rarity: 'uncommon',
        value: 35,
        quantity: 3,
        stats: { healAmount: 65 },
      },
      {
        id: 'potion_thunderbolt',
        name: 'Эликсир «Гром»',
        description: '+35% к силе атаки на 45 сек и +40 ОЗ (+25 Токсичности).',
        category: 'potion',
        rarity: 'rare',
        value: 50,
        quantity: 2,
        stats: { healAmount: 40, staminaBoost: 70 },
      },
      {
        id: 'potion_cat',
        name: 'Эликсир «Кошка»',
        description: 'Дарует ночное зрение в темноте и катакомбах на 60 сек (+15 Токсичности).',
        category: 'potion',
        rarity: 'uncommon',
        value: 40,
        quantity: 1,
        stats: { healAmount: 25 },
      },
      {
        id: 'potion_blizzard',
        name: 'Эликсир «Пурга»',
        description: 'Ускоряет рефлексы и восстанавливает 80 выносливости (+20 Токсичности).',
        category: 'potion',
        rarity: 'rare',
        value: 55,
        quantity: 1,
        stats: { staminaBoost: 80 },
      },
      {
        id: 'iron_ore',
        name: 'Тёмная железная руда',
        description: 'Необходима кузнецу для закалки оружия и ковки по чертежам.',
        category: 'resource',
        rarity: 'common',
        value: 25,
        quantity: 3,
      },
      {
        id: 'herb_swallow',
        name: 'Ласточкина трава',
        description: 'Целебное растение для варки ведьмачьих эликсиров.',
        category: 'resource',
        rarity: 'common',
        value: 12,
        quantity: 3,
      },
      {
        id: 'rune_fire',
        name: 'Рунический камень Огня (Игнис)',
        description: 'Вставляется в меч: придаёт лезвию огненное свечение и +8 к урону.',
        category: 'rune',
        rarity: 'rare',
        value: 75,
        quantity: 1,
        stats: { runeEffect: 'fire', attack: 8, silverAttack: 8 },
      },
      {
        id: 'bp_raven_armor',
        name: 'Чертёж: Доспех Школы Ворона',
        description: 'Лёгкий доспех (Сет Ворона: +25% реген выносливости, +20% шанс крита).',
        category: 'blueprint',
        rarity: 'rare',
        value: 95,
        quantity: 1,
        craftsItemId: 'set_raven_armor',
        craftRecipe: [
          { itemId: 'iron_ore', count: 1 },
          { itemId: 'wolf_pelt', count: 1 },
        ],
      },
      {
        id: 'bp_raven_sword',
        name: 'Чертёж: Клинок Школы Ворона',
        description: 'Серебряный и стальной клинок Ворона (Сет Ворона: +20% крит и скорость).',
        category: 'blueprint',
        rarity: 'rare',
        value: 110,
        quantity: 1,
        craftsItemId: 'set_raven_sword',
        craftRecipe: [
          { itemId: 'iron_ore', count: 2 },
          { itemId: 'monster_claw', count: 1 },
        ],
      },
    ];
  }

  public initShopCatalog(): void {
    this.shopCatalog = [
      {
        id: 'potion_swallow',
        name: 'Эликсир «Ласточка»',
        description: 'Восстанавливает 65 ед. здоровья.',
        category: 'potion',
        rarity: 'uncommon',
        value: 40,
        quantity: 99,
        stats: { healAmount: 65 },
      },
      {
        id: 'potion_thunderbolt',
        name: 'Эликсир «Гром»',
        description: '+35% к атаке на 45 сек и +40 ОЗ.',
        category: 'potion',
        rarity: 'rare',
        value: 55,
        quantity: 99,
        stats: { healAmount: 40, staminaBoost: 70 },
      },
      {
        id: 'iron_ore',
        name: 'Тёмная железная руда',
        description: 'Слиток руды для ковки и улучшения снаряжения у кузнеца.',
        category: 'resource',
        rarity: 'common',
        value: 30,
        quantity: 99,
      },
      {
        id: 'herb_swallow',
        name: 'Ласточкина трава',
        description: 'Алхимическая трава для варки эликсиров [N].',
        category: 'resource',
        rarity: 'common',
        value: 15,
        quantity: 99,
      },
      {
        id: 'rune_vamp',
        name: 'Руна Вампиризма (Мортана)',
        description: 'Вставляется в оружие: исцеляет героя на 5% от нанесённого урона.',
        category: 'rune',
        rarity: 'relic',
        value: 110,
        quantity: 3,
        stats: { runeEffect: 'vamp', silverAttack: 10 },
      },
      {
        id: 'rune_bleed',
        name: 'Руна Кровотечения',
        description: 'Вставляется в оружие: рассекает плоть врагов (+9 к атаке).',
        category: 'rune',
        rarity: 'rare',
        value: 85,
        quantity: 3,
        stats: { runeEffect: 'bleed', attack: 9, silverAttack: 9 },
      },
      {
        id: 'bp_bear_armor',
        name: 'Чертёж: Тяжёлый доспех Школы Медведя',
        description: 'Тяжёлые латы (Сет Медведя: +40% к броне, усиление Барьера и тяж. ударов).',
        category: 'blueprint',
        rarity: 'relic',
        value: 120,
        quantity: 1,
        craftsItemId: 'set_bear_armor',
        craftRecipe: [
          { itemId: 'iron_ore', count: 2 },
          { itemId: 'wolf_pelt', count: 1 },
        ],
      },
      {
        id: 'bp_flame_armor',
        name: 'Чертёж: Облачение Школы Пламени',
        description: 'Рунический доспех (Сет Пламени: +35% к урону Знаков, огненный шлейф).',
        category: 'blueprint',
        rarity: 'relic',
        value: 125,
        quantity: 1,
        craftsItemId: 'set_flame_armor',
        craftRecipe: [
          { itemId: 'iron_ore', count: 2 },
          { itemId: 'ghoul_blood', count: 1 },
        ],
      },
      {
        id: 'sword_temerian_silver',
        name: 'Мастерский серебряный клинок Зари',
        description: 'Реликвия старых мастеров с повышенным уроном по нечисти.',
        category: 'weapon',
        rarity: 'relic',
        value: 210,
        quantity: 1,
        upgradeLevel: 0,
        stats: { silverAttack: 36, signIntensity: 15 },
      },
      {
        id: 'bp_frost_warden_armor',
        name: 'Чертёж: Доспех Хранителя Хлада (Тир-4)',
        description: 'Северный латный комплект Среброзубого Перевала: удары мечом накладывают мороз и замедляют врагов.',
        category: 'blueprint',
        rarity: 'relic',
        value: 165,
        quantity: 1,
        craftsItemId: 'set_frost_warden_armor',
        craftRecipe: [
          { itemId: 'iron_ore', count: 1 },
          { itemId: 'ice_lotus', count: 1 },
        ],
      },
      {
        id: 'bp_grandmaster_armor',
        name: 'Чертёж: Доспех Грандмастера Пепла (Тир-5)',
        description: 'Высшее облачение Чёрного Бастиона: усиливает все 5 Печатей (+65%) и даёт двойной рывок с теневым следом.',
        category: 'blueprint',
        rarity: 'relic',
        value: 220,
        quantity: 1,
        craftsItemId: 'set_grandmaster_armor',
        craftRecipe: [
          { itemId: 'black_ore', count: 1 },
          { itemId: 'iron_ore', count: 1 },
        ],
      },
      {
        id: 'bp_obsidian_armor',
        name: 'Чертёж: Латы Обсидианового Стража (Тир-5)',
        description: 'Броня Кратера Затмения: дарует иммунитет к прерыванию атак и возвращает 20% урона врагам.',
        category: 'blueprint',
        rarity: 'relic',
        value: 240,
        quantity: 1,
        craftsItemId: 'set_obsidian_armor',
        craftRecipe: [
          { itemId: 'black_ore', count: 1 },
          { itemId: 'void_dust', count: 1 },
        ],
      },
      {
        id: 'rune_frost_sup',
        name: 'Высшая Руна Вечной Мерзлоты',
        description: 'Замораживает кровь врагов при ударе (+16 к серебру, +20% к Печатям).',
        category: 'rune',
        rarity: 'relic',
        value: 145,
        quantity: 2,
        stats: { runeEffect: 'frost', attack: 14, silverAttack: 16, signIntensity: 20 },
      },
      {
        id: 'rune_void_sup',
        name: 'Высшая Руна Сердца Пустоты',
        description: 'Обжигает врагов багровой энергией Бездны (+20 к урону сталью и серебром).',
        category: 'rune',
        rarity: 'relic',
        value: 175,
        quantity: 2,
        stats: { runeEffect: 'void', attack: 20, silverAttack: 20, critChanceBonus: 0.1 },
      },
    ];
  }

  public initSkillTree(): void {
    this.skills = [
      {
        id: 'skill_blade_mastery',
        branch: 'combat',
        name: 'Память тела',
        description: 'Увеличивает базовый урон быстрых и тяжёлых ударов мечом (+5 за уровень).',
        level: 0,
        maxLevel: 5,
        cost: 1,
      },
      {
        id: 'skill_crushing_blow',
        branch: 'combat',
        name: 'Сокрушительный натиск',
        description: 'Дополнительно усиливает все типы атак (+3 к урону за уровень).',
        level: 0,
        maxLevel: 3,
        cost: 1,
      },
      {
        id: 'skill_runic_focus',
        branch: 'signs',
        name: 'Мощь Рунных Знаков',
        description: 'Повышает интенсивность всех магических знаков на +15% за уровень.',
        level: 0,
        maxLevel: 5,
        cost: 1,
      },
      {
        id: 'skill_witcher_vitality',
        branch: 'alchemy',
        name: 'Мутация выносливости',
        description: 'Повышает максимальное здоровье на +25 и защиту на +3 за уровень.',
        level: 0,
        maxLevel: 5,
        cost: 1,
      },
    ];
  }

  private getItemDefinitions(): Record<string, Omit<GameItem, 'quantity'>> {
    return {
      monster_claw: {
        id: 'monster_claw',
        name: 'Коготь чудовища',
        description: 'Острый трофейный коготь для кузнечной ковки и алхимии.',
        category: 'resource',
        rarity: 'common',
        value: 18,
      },
      ghoul_blood: {
        id: 'ghoul_blood',
        name: 'Кровь упыря',
        description: 'Густая алхимическая субстанция для варки эликсиров.',
        category: 'resource',
        rarity: 'uncommon',
        value: 24,
      },
      wolf_pelt: {
        id: 'wolf_pelt',
        name: 'Волчья шкура',
        description: 'Прочная шкура лесного хищника для пошива ведьмачьих доспехов.',
        category: 'resource',
        rarity: 'common',
        value: 20,
      },
      black_ore: {
        id: 'black_ore',
        name: 'Чёрная руда',
        description: 'Кристаллизованная кровь Древнего Бога из Мёртвых Шахт. Необходима для ковки снаряжения Тир-5 и отваров.',
        category: 'resource',
        rarity: 'relic',
        value: 65,
      },
      hydra_heart: {
        id: 'hydra_heart',
        name: 'Сердце гидры',
        description: 'Пульсирующее сердце Матери Трясины. Ключевой реагент для Отвара Матери Трясины.',
        category: 'resource',
        rarity: 'relic',
        value: 140,
      },
      void_dust: {
        id: 'void_dust',
        name: 'Пыль пустоты',
        description: 'Сияющий пепел из Кратера Затмения для Высшей Алхимии и обсидиановой ковки.',
        category: 'resource',
        rarity: 'rare',
        value: 55,
      },
      ice_lotus: {
        id: 'ice_lotus',
        name: 'Ледяной лотос',
        description: 'Редкий морозный цветок со скал Среброзубого Перевала для отваров и брони Хранителя Хлада.',
        category: 'resource',
        rarity: 'rare',
        value: 45,
      },
      cursed_essence: {
        id: 'cursed_essence',
        name: 'Трофей: Голова Болотной ведьмы',
        description: 'Даёт +15% к силе Знаков и +25 к Здоровью при экипировке на пояс.',
        category: 'trophy',
        rarity: 'relic',
        value: 120,
        equipped: true,
        stats: { signIntensity: 15, maxHealth: 25 },
      },
      demon_heart: {
        id: 'demon_heart',
        name: 'Трофей: Сердце Лесного демона',
        description: 'Древний трофей, дающий +10 к атаке и +40 к здоровью.',
        category: 'trophy',
        rarity: 'relic',
        value: 160,
        equipped: true,
        stats: { attack: 10, silverAttack: 10, maxHealth: 40 },
      },
      trophy_werewolf: {
        id: 'trophy_werewolf',
        name: 'Трофей: Клык Альфа-Воколака',
        description: 'Трофей на пояс за контракт «Вой в ночи»: +15% к шансу крит. удара и +12 к атаке.',
        category: 'trophy',
        rarity: 'relic',
        value: 180,
        equipped: true,
        stats: { critChanceBonus: 0.15, attack: 12, silverAttack: 12 },
      },
      trophy_noonwraith: {
        id: 'trophy_noonwraith',
        name: 'Трофей: Венок Полуденницы',
        description: 'Трофей на пояс за контракт «Невеста у колодца»: регенерация +4 ОЗ/сек и +20% к Знакам.',
        category: 'trophy',
        rarity: 'relic',
        value: 185,
        equipped: true,
        stats: { hpRegenBonus: 4, signIntensity: 20 },
      },
      trophy_gargoyle: {
        id: 'trophy_gargoyle',
        name: 'Трофей: Сердце Каменного Жнеца',
        description: 'Трофей на пояс за контракт «Каменный жнец»: +15% к находимому золоту и +12 к броне.',
        category: 'trophy',
        rarity: 'relic',
        value: 195,
        equipped: true,
        stats: { goldBonus: 0.15, defense: 12 },
      },
      king_crown_shard: {
        id: 'king_crown_shard',
        name: 'Корона Падшего Монарха',
        description: 'Королевская реликвия Древнего Хранителя (+20 к урону, +30% к Знакам).',
        category: 'trophy',
        rarity: 'relic',
        value: 350,
        equipped: true,
        stats: { attack: 20, silverAttack: 20, signIntensity: 30 },
      },
      relic_blade: {
        id: 'relic_blade',
        name: 'Клинок Старого Королевства',
        description: 'Легендарный двуручный меч Хранителя.',
        category: 'weapon',
        rarity: 'relic',
        value: 300,
        equipped: true,
        upgradeLevel: 1,
        stats: { attack: 35, silverAttack: 45 },
      },
      sword_catacombs_king: {
        id: 'sword_catacombs_king',
        name: 'Легендарный меч «Клятва Древних Королей»',
        description: 'Сокровище подземных катакомб: наносит колоссальный урон и усиливает Знаки.',
        category: 'weapon',
        rarity: 'relic',
        value: 380,
        equipped: true,
        upgradeLevel: 1,
        setId: 'flame',
        stats: { attack: 42, silverAttack: 52, signIntensity: 30, critChanceBonus: 0.15 },
      },
      sword_crimson_order: {
        id: 'sword_crimson_order',
        name: 'Освящённый клинок Алого Солнца',
        description: 'Фракционное оружие Инквизитора Лазаря (Акт II: +45 к атаке и огненная руна).',
        category: 'weapon',
        rarity: 'relic',
        value: 340,
        equipped: true,
        setId: 'flame',
        socketedRuneId: 'rune_fire',
        stats: { attack: 44, silverAttack: 46, signIntensity: 25, runeEffect: 'fire' },
      },
      sword_coven_protector: {
        id: 'sword_coven_protector',
        name: 'Рунный клинок Защитника Пади',
        description: 'Дар Старосты и Ковена за защиту деревни (Акт II: +46 к серебру и вампиризм).',
        category: 'weapon',
        rarity: 'relic',
        value: 340,
        equipped: true,
        setId: 'raven',
        socketedRuneId: 'rune_vamp',
        stats: { attack: 40, silverAttack: 48, critChanceBonus: 0.15, runeEffect: 'vamp' },
      },
      // =======================================================================
      // 5 МИФИЧЕСКИХ ОРУЖИЙ СЕВЕРНОГО ПОХОДА
      // =======================================================================
      mythic_sun_eater: {
        id: 'mythic_sun_eater',
        name: 'Двуручный клинок «Пожиратель Солнца»',
        description: 'Мифическое оружие Кратера Затмения: тяжёлые удары выпускают испепеляющие огненные волны.',
        category: 'weapon',
        rarity: 'relic',
        value: 520,
        equipped: true,
        upgradeLevel: 2,
        setId: 'obsidian',
        mythicPassive: 'sun_eater',
        stats: { attack: 58, silverAttack: 64, signIntensity: 35, runeEffect: 'fire' },
      },
      mythic_dusk_fangs: {
        id: 'mythic_dusk_fangs',
        name: 'Парные клинки Веспера «Клыки Заката»',
        description: 'Личное оружие Грандмастера Братства Пепла: сверхбыстрые серии ударов и исцеление вампиризмом (12% от урона).',
        category: 'weapon',
        rarity: 'relic',
        value: 540,
        equipped: true,
        upgradeLevel: 2,
        setId: 'grandmaster',
        mythicPassive: 'dusk_fangs',
        stats: { attack: 54, silverAttack: 62, critChanceBonus: 0.25, runeEffect: 'vamp' },
      },
      mythic_void_voice: {
        id: 'mythic_void_voice',
        name: 'Клинок «Глас Бездны»',
        description: 'Выкован из осколка Трона Пустоты: полностью игнорирует и пробивает любую броню, панцири и щиты врагов.',
        category: 'weapon',
        rarity: 'relic',
        value: 560,
        equipped: true,
        upgradeLevel: 2,
        setId: 'grandmaster',
        mythicPassive: 'void_voice',
        stats: { attack: 60, silverAttack: 68, signIntensity: 40, runeEffect: 'void' },
      },
      mythic_black_cleaver: {
        id: 'mythic_black_cleaver',
        name: 'Колун Чёрной Руды',
        description: 'Мифический трофей Мёртвых Шахт: мгновенно раскалывает кристальную броню големов и оглушает врагов.',
        category: 'weapon',
        rarity: 'relic',
        value: 460,
        equipped: true,
        upgradeLevel: 1,
        setId: 'frost_warden',
        mythicPassive: 'black_cleaver',
        stats: { attack: 52, silverAttack: 56, defense: 14, runeEffect: 'frost' },
      },
      mythic_plague_scythe: {
        id: 'mythic_plague_scythe',
        name: 'Коса Чумного Жнеца',
        description: 'Мифическое оружие Затопленных Топей: каждый удар накладывает смертоносное ядовитое кровотечение.',
        category: 'weapon',
        rarity: 'relic',
        value: 440,
        equipped: true,
        upgradeLevel: 1,
        mythicPassive: 'plague_scythe',
        stats: { attack: 48, silverAttack: 54, critChanceBonus: 0.18, runeEffect: 'bleed' },
      },
      // =======================================================================
      // КОМПЛЕКТЫ ТИР-4 И ТИР-5 СЕВЕРНОГО ПОХОДА
      // =======================================================================
      set_frost_warden_armor: {
        id: 'set_frost_warden_armor',
        name: 'Доспех Хранителя Хлада (Тир-4)',
        description: 'Сет Хранителя Хлада: удары мечом накладывают мороз и замедляют врагов, +30% к броне.',
        category: 'armor',
        rarity: 'relic',
        value: 360,
        equipped: true,
        setId: 'frost_warden',
        stats: { defense: 34, maxHealth: 105, signIntensity: 30 },
      },
      set_frost_warden_sword: {
        id: 'set_frost_warden_sword',
        name: 'Ледяной клинок Среброзуба (Тир-4)',
        description: 'Парный клинок комплекта Хранителя Хлада, сковывающий движения чудовищ.',
        category: 'weapon',
        rarity: 'relic',
        value: 350,
        equipped: true,
        setId: 'frost_warden',
        stats: { attack: 45, silverAttack: 50, signIntensity: 25, runeEffect: 'frost' },
      },
      set_grandmaster_armor: {
        id: 'set_grandmaster_armor',
        name: 'Доспех Грандмастера Пепла (Тир-5)',
        description: 'Высший сет Чёрного Бастиона: усиливает все 5 Знаков (+65% мощи) и даёт двойной рывок с теневым следом.',
        category: 'armor',
        rarity: 'relic',
        value: 480,
        equipped: true,
        setId: 'grandmaster',
        stats: { defense: 40, maxHealth: 130, signIntensity: 55, critChanceBonus: 0.15 },
      },
      set_grandmaster_sword: {
        id: 'set_grandmaster_sword',
        name: 'Клинок Великого Магистра Пепла (Тир-5)',
        description: 'Реликтовый меч Грандмастера Пепла с рунами всех пяти стихий.',
        category: 'weapon',
        rarity: 'relic',
        value: 490,
        equipped: true,
        setId: 'grandmaster',
        stats: { attack: 55, silverAttack: 62, signIntensity: 45, critChanceBonus: 0.2 },
      },
      set_obsidian_armor: {
        id: 'set_obsidian_armor',
        name: 'Латы Обсидианового Стража (Тир-5)',
        description: 'Сет Обсидианового Стража: даёт иммунитет к прерыванию атак и возвращает 20% урона врагам.',
        category: 'armor',
        rarity: 'relic',
        value: 510,
        equipped: true,
        setId: 'obsidian',
        stats: { defense: 48, maxHealth: 160 },
      },
      set_obsidian_sword: {
        id: 'set_obsidian_sword',
        name: 'Обсидиановый Бастард Трона (Тир-5)',
        description: 'Тяжёлый меч комплекта Обсидианового Стража.',
        category: 'weapon',
        rarity: 'relic',
        value: 500,
        equipped: true,
        setId: 'obsidian',
        stats: { attack: 56, silverAttack: 60, defense: 15 },
      },
      // =======================================================================
      // ВЫСШАЯ АЛХИМИЯ: ОТВАРЫ ИЗ ТРОФЕЕВ БОССОВ
      // =======================================================================
      decoction_hydra: {
        id: 'decoction_hydra',
        name: 'Отвар из Матери Трясины',
        description: 'Трофейный отвар: +8 ОЗ/сек регенерации, +60 макс. ОЗ и полный иммунитет к болотному яду на 180 сек.',
        category: 'potion',
        rarity: 'relic',
        value: 160,
        decoctionEffect: 'hydra',
        stats: { healAmount: 90, hpRegenBonus: 8 },
      },
      decoction_colossus: {
        id: 'decoction_colossus',
        name: 'Отвар из Кристального Колосса',
        description: 'Трофейный отвар: +22 к Броне, +80 макс. ОЗ и каменная несокрушимость на 180 сек.',
        category: 'potion',
        rarity: 'relic',
        value: 170,
        decoctionEffect: 'colossus',
        stats: { healAmount: 80, defense: 22 },
      },
      decoction_vesper: {
        id: 'decoction_vesper',
        name: 'Отвар Тлеющей Крови',
        description: 'Трофейный отвар Братства: +20% к урону мечом, +20% крит и +40% мощи Печатей на 180 сек.',
        category: 'potion',
        rarity: 'relic',
        value: 190,
        decoctionEffect: 'vesper',
        stats: { healAmount: 75, staminaBoost: 100 },
      },
      set_raven_armor: {
        id: 'set_raven_armor',
        name: 'Доспех Школы Ворона',
        description: 'Комплект Ворона (Тёмно-синяя кожа и вороненая сталь: +20% крит, +25% выносливость).',
        category: 'armor',
        rarity: 'relic',
        value: 220,
        equipped: true,
        setId: 'raven',
        stats: { defense: 18, maxHealth: 45, critChanceBonus: 0.1 },
      },
      set_raven_sword: {
        id: 'set_raven_sword',
        name: 'Клинок Школы Ворона',
        description: 'Стремительный клинок комплекта Школы Ворона.',
        category: 'weapon',
        rarity: 'relic',
        value: 230,
        equipped: true,
        setId: 'raven',
        stats: { attack: 28, silverAttack: 34, critChanceBonus: 0.1 },
      },
      set_bear_armor: {
        id: 'set_bear_armor',
        name: 'Тяжёлый доспех Школы Медведя',
        description: 'Комплект Медведя (Тяжёлые латы и мех: +40% к броне, усиление «Барьера»).',
        category: 'armor',
        rarity: 'relic',
        value: 260,
        equipped: true,
        setId: 'bear',
        stats: { defense: 28, maxHealth: 90 },
      },
      set_bear_sword: {
        id: 'set_bear_sword',
        name: 'Тяжёлый меч Школы Медведя',
        description: 'Мощный клинок комплекта Школы Медведя для сокрушительных ударов.',
        category: 'weapon',
        rarity: 'relic',
        value: 250,
        equipped: true,
        setId: 'bear',
        stats: { attack: 34, silverAttack: 38, defense: 8 },
      },
      set_flame_armor: {
        id: 'set_flame_armor',
        name: 'Рунический доспех Школы Пламени',
        description: 'Комплект Пламени (Багрово-золотые латы: +35% к урону всех Знаков и огненный шлейф).',
        category: 'armor',
        rarity: 'relic',
        value: 250,
        equipped: true,
        setId: 'flame',
        stats: { defense: 21, maxHealth: 60, signIntensity: 30 },
      },
      set_flame_sword: {
        id: 'set_flame_sword',
        name: 'Пламенный клинок Игниса',
        description: 'Рунический меч комплекта Школы Пламени.',
        category: 'weapon',
        rarity: 'relic',
        value: 255,
        equipped: true,
        setId: 'flame',
        socketedRuneId: 'rune_fire',
        stats: { attack: 30, silverAttack: 38, signIntensity: 25, runeEffect: 'fire' },
      },
      bp_bear_sword: {
        id: 'bp_bear_sword',
        name: 'Чертёж: Тяжёлый меч Школы Медведя',
        description: 'Позволяет выковать у кузнеца меч Школы Медведя.',
        category: 'blueprint',
        rarity: 'relic',
        value: 115,
        craftsItemId: 'set_bear_sword',
        craftRecipe: [
          { itemId: 'iron_ore', count: 2 },
          { itemId: 'monster_claw', count: 1 },
        ],
      },
      bp_flame_sword: {
        id: 'bp_flame_sword',
        name: 'Чертёж: Пламенный клинок Игниса',
        description: 'Позволяет выковать у кузнеца клинок Школы Пламени.',
        category: 'blueprint',
        rarity: 'relic',
        value: 120,
        craftsItemId: 'set_flame_sword',
        craftRecipe: [
          { itemId: 'iron_ore', count: 2 },
          { itemId: 'ghoul_blood', count: 1 },
        ],
      },
      bp_frost_warden_sword: {
        id: 'bp_frost_warden_sword',
        name: 'Чертёж: Ледяной клинок Среброзуба (Тир-4)',
        description: 'Позволяет выковать у кузнеца меч Хранителя Хлада.',
        category: 'blueprint',
        rarity: 'relic',
        value: 160,
        craftsItemId: 'set_frost_warden_sword',
        craftRecipe: [
          { itemId: 'black_ore', count: 1 },
          { itemId: 'ice_lotus', count: 1 },
        ],
      },
      bp_grandmaster_sword: {
        id: 'bp_grandmaster_sword',
        name: 'Чертёж: Клинок Великого Магистра Пепла (Тир-5)',
        description: 'Позволяет выковать высший клинок Чёрного Бастиона.',
        category: 'blueprint',
        rarity: 'relic',
        value: 210,
        craftsItemId: 'set_grandmaster_sword',
        craftRecipe: [
          { itemId: 'black_ore', count: 2 },
          { itemId: 'void_dust', count: 1 },
        ],
      },
      bp_obsidian_sword: {
        id: 'bp_obsidian_sword',
        name: 'Чертёж: Обсидиановый Бастард Трона (Тир-5)',
        description: 'Позволяет выковать тяжёлый обсидиановый клинок Кратера Затмения.',
        category: 'blueprint',
        rarity: 'relic',
        value: 225,
        craftsItemId: 'set_obsidian_sword',
        craftRecipe: [
          { itemId: 'black_ore', count: 2 },
          { itemId: 'void_dust', count: 1 },
        ],
      },
      rune_fire: {
        id: 'rune_fire',
        name: 'Рунический камень Огня (Игнис)',
        description: 'Вставляется в меч: придаёт лезвию огненное свечение и +8 к урону.',
        category: 'rune',
        rarity: 'rare',
        value: 75,
        stats: { runeEffect: 'fire', attack: 8, silverAttack: 8 },
      },
      rune_vamp: {
        id: 'rune_vamp',
        name: 'Руна Вампиризма (Мортана)',
        description: 'Вставляется в оружие: исцеляет героя на 5% от нанесённого урона.',
        category: 'rune',
        rarity: 'relic',
        value: 110,
        stats: { runeEffect: 'vamp', silverAttack: 10 },
      },
      rune_bleed: {
        id: 'rune_bleed',
        name: 'Руна Кровотечения',
        description: 'Вставляется в оружие: рассекает плоть врагов (+9 к атаке).',
        category: 'rune',
        rarity: 'rare',
        value: 85,
        stats: { runeEffect: 'bleed', attack: 9, silverAttack: 9 },
      },
      rune_ward: {
        id: 'rune_ward',
        name: 'Руна Защиты (Квен)',
        description: 'Вставляется в броню: повышает защиту на +8 и интенсивность Знаков на +12%.',
        category: 'rune',
        rarity: 'rare',
        value: 80,
        stats: { runeEffect: 'ward', defense: 8, signIntensity: 12 },
      },
      rune_frost_sup: {
        id: 'rune_frost_sup',
        name: 'Высшая Руна Вечной Мерзлоты',
        description: 'Замораживает врагов при ударе (+16 к серебру, +20% к Печатям).',
        category: 'rune',
        rarity: 'relic',
        value: 145,
        stats: { runeEffect: 'frost', attack: 14, silverAttack: 16, signIntensity: 20 },
      },
      rune_void_sup: {
        id: 'rune_void_sup',
        name: 'Высшая Руна Сердца Пустоты',
        description: 'Обжигает врагов багровой энергией Бездны (+20 к урону).',
        category: 'rune',
        rarity: 'relic',
        value: 175,
        stats: { runeEffect: 'void', attack: 20, silverAttack: 20, critChanceBonus: 0.1 },
      },
      sword_hunter_steel: {
        id: 'sword_hunter_steel',
        name: 'Закалённый меч Вороньей Пади',
        description: 'Награда старосты Боримира за спасение деревни.',
        category: 'weapon',
        rarity: 'rare',
        value: 135,
        equipped: true,
        upgradeLevel: 0,
        stats: { attack: 24 },
      },
      sword_ancient_king: {
        id: 'sword_ancient_king',
        name: 'Серебряный клинок Династии',
        description: 'Древний королевский клинок, разящий любую нечисть.',
        category: 'weapon',
        rarity: 'relic',
        value: 280,
        equipped: true,
        upgradeLevel: 1,
        stats: { silverAttack: 42, signIntensity: 20 },
      },
      armor_royal_guard: {
        id: 'armor_royal_guard',
        name: 'Латы Королевской Гвардии',
        description: 'Реликвия из сокровищницы разрушенной крепости.',
        category: 'armor',
        rarity: 'relic',
        value: 240,
        equipped: true,
        upgradeLevel: 0,
        setId: 'bear',
        stats: { defense: 24, maxHealth: 80 },
      },
      amulet_abyss: {
        id: 'amulet_abyss',
        name: 'Рунный оберег Проклятого Алтаря',
        description: 'Укрощённая мощь святилища (+25% к Знакам и +30 ОЗ).',
        category: 'trophy',
        rarity: 'relic',
        value: 180,
        equipped: true,
        stats: { signIntensity: 25, maxHealth: 30 },
      },
      herb_swallow: {
        id: 'herb_swallow',
        name: 'Ласточкина трава',
        description: 'Целебное растение для алхимии и продажи.',
        category: 'resource',
        rarity: 'common',
        value: 12,
      },
      iron_ore: {
        id: 'iron_ore',
        name: 'Тёмная железная руда',
        description: 'Необходима кузнецу для закалки оружия и брони.',
        category: 'resource',
        rarity: 'common',
        value: 25,
      },
      potion_swallow: {
        id: 'potion_swallow',
        name: 'Эликсир «Ласточка»',
        description: 'Мгновенно восстанавливает 65 ед. здоровья в бою.',
        category: 'potion',
        rarity: 'uncommon',
        value: 35,
        stats: { healAmount: 65 },
      },
      potion_thunderbolt: {
        id: 'potion_thunderbolt',
        name: 'Эликсир «Гром»',
        description: '+35% к силе атаки на 45 сек и +40 ОЗ.',
        category: 'potion',
        rarity: 'rare',
        value: 50,
        stats: { healAmount: 40, staminaBoost: 70 },
      },
      potion_cat: {
        id: 'potion_cat',
        name: 'Эликсир «Кошка»',
        description: 'Ночное зрение в темноте и склепах на 60 сек.',
        category: 'potion',
        rarity: 'uncommon',
        value: 40,
        stats: { healAmount: 25 },
      },
      potion_blizzard: {
        id: 'potion_blizzard',
        name: 'Эликсир «Пурга»',
        description: 'Замедление времени при уклонении и +80 выносливости.',
        category: 'potion',
        rarity: 'rare',
        value: 55,
        stats: { staminaBoost: 80 },
      },
    };
  }

  public addItemById(itemId: string, count = 1, autoEquip = false): GameItem {
    const existing = this.items.find((i) => i.id === itemId);
    if (existing) {
      existing.quantity += count;
      if (autoEquip) {
        this.equipItem(existing.id);
      }
      return existing;
    }

    const definitions = this.getItemDefinitions();
    const def = definitions[itemId] ?? {
      id: itemId,
      name: 'Древний трофей',
      description: 'Предмет из Забытых земель.',
      category: 'resource',
      rarity: 'common',
      value: 15,
    };

    const slot = getItemEquipSlot({ ...def, quantity: count });
    const newItem: GameItem = {
      ...def,
      equipSlot: slot ?? undefined,
      quantity: count,
      equipped: false,
    };
    this.items.push(newItem);

    // If autoEquip is requested, or if no item is currently equipped in that slot, equip it cleanly
    if (slot) {
      const currentlyInSlot = this.getEquippedBySlot(slot);
      if (autoEquip || !currentlyInSlot) {
        this.equipItem(newItem.id);
      }
    }

    return newItem;
  }

  public getEquippedBySlot(slot: EquipmentSlot): GameItem | undefined {
    return this.items.find((i) => i.equipped && getItemEquipSlot(i) === slot);
  }

  public sanitizeEquipment(): void {
    this.items = enforceExclusiveEquipment(this.items);
  }

  public equipItem(itemId: string): { replacedItem?: GameItem } {
    const item = this.items.find((i) => i.id === itemId);
    if (!item) return {};
    const slot = getItemEquipSlot(item);
    if (!slot) return {};

    let replacedItem: GameItem | undefined;
    for (const other of this.items) {
      if (other.id !== item.id && other.equipped && getItemEquipSlot(other) === slot) {
        other.equipped = false;
        replacedItem = other;
      }
    }
    item.equipSlot = slot;
    item.equipped = true;
    return { replacedItem };
  }

  public useQuickPotion(
    player: PlayerStats,
    maxHp: number,
    specificPotionId?: string
  ): { used: boolean; message: string } {
    if (player.potionCooldown > 0) {
      return { used: false, message: 'Эликсир ещё усваивается' };
    }
    if (player.toxicity >= player.maxToxicity - 10) {
      return { used: false, message: 'Слишком высокая интоксикация! Отдохните у костра.' };
    }

    const potion = specificPotionId
      ? this.items.find((i) => i.id === specificPotionId && i.quantity > 0)
      : this.items.find((i) => i.category === 'potion' && i.quantity > 0);

    if (!potion) {
      return { used: false, message: 'Нет эликсиров в инвентаре (Сварите в Алхимии [N])' };
    }

    potion.quantity -= 1;
    player.toxicity = Math.min(player.maxToxicity, (player.toxicity ?? 0) + 22);

    if (potion.stats?.healAmount) {
      player.hp = Math.min(maxHp, player.hp + potion.stats.healAmount);
    }
    if (potion.stats?.staminaBoost) {
      player.stamina = Math.min(
        player.maxStamina,
        player.stamina + potion.stats.staminaBoost
      );
    }

    if (potion.id === 'potion_thunderbolt') {
      player.thunderElixirTimer = 45;
    } else if (potion.id === 'potion_cat') {
      player.catElixirTimer = 60;
    } else if (potion.id === 'potion_blizzard') {
      player.blizzardElixirTimer = 40;
    } else if (potion.id === 'decoction_hydra') {
      player.activeDecoction = 'hydra';
      player.decoctionTimer = 180;
      player.poisonTimer = 0;
    } else if (potion.id === 'decoction_colossus') {
      player.activeDecoction = 'colossus';
      player.decoctionTimer = 180;
    } else if (potion.id === 'decoction_vesper') {
      player.activeDecoction = 'vesper';
      player.decoctionTimer = 180;
    }

    player.potionCooldown = 2.0;
    return { used: true, message: `Выпит эликсир: ${potion.name} (+22 Токсичности)` };
  }

  public brewElixir(
    elixirId:
      | 'potion_swallow'
      | 'potion_thunderbolt'
      | 'potion_cat'
      | 'potion_blizzard'
      | 'decoction_hydra'
      | 'decoction_colossus'
      | 'decoction_vesper'
  ): { ok: boolean; message: string } {
    if (elixirId.startsWith('decoction_')) {
      const herb = this.items.find((i) => i.id === 'herb_swallow' && i.quantity >= 1);
      const special =
        this.items.find(
          (i) =>
            (i.id === 'hydra_heart' ||
              i.id === 'black_ore' ||
              i.id === 'void_dust' ||
              i.id === 'ice_lotus' ||
              i.id === 'cursed_essence') &&
            i.quantity >= 1
        ) ?? herb;
      if (!special || special.quantity < 1) {
        return {
          ok: false,
          message: 'Недостаточно реагентов Севера или Ласточкиной травы (нужно 1 шт.)',
        };
      }
      special.quantity -= 1;
      const brewedDecoction = this.addItemById(elixirId, 1);
      return {
        ok: true,
        message: `Сварен трофейный отвар: ${brewedDecoction.name}!`,
      };
    }

    const herb = this.items.find((i) => i.id === 'herb_swallow');
    if (!herb || herb.quantity < 1) {
      return { ok: false, message: 'Недостаточно Ласточкиной травы (нужно 1 шт.)' };
    }

    herb.quantity -= 1;
    const brewed = this.addItemById(elixirId, 2);
    return { ok: true, message: `Сварен эликсир: ${brewed.name} (x2)!` };
  }

  public craftBlueprint(
    blueprintId: string,
    player: PlayerStats
  ): { ok: boolean; message: string } {
    const bp = this.items.find((i) => i.id === blueprintId && i.category === 'blueprint');
    if (!bp || !bp.craftsItemId) {
      return { ok: false, message: 'Чертёж не найден' };
    }

    const goldCost = 70;
    if (player.gold < goldCost) {
      return { ok: false, message: `Недостаточно золота для работы кузнеца (${goldCost} крон)` };
    }

    const ore =
      this.items.find((i) => i.id === 'black_ore' && i.quantity >= 1) ??
      this.items.find((i) => i.id === 'iron_ore' && i.quantity >= 1);
    if (!ore || ore.quantity < 1) {
      return { ok: false, message: 'Нужна хотя бы 1 Тёмная или Чёрная руда' };
    }

    player.gold -= goldCost;
    ore.quantity -= 1;
    const crafted = this.addItemById(bp.craftsItemId, 1, true);
    return {
      ok: true,
      message: `Выковано и экипировано по чертежу: ${crafted.name}!`,
    };
  }

  public socketRune(
    targetItemId: string,
    runeItemId: string
  ): { ok: boolean; message: string } {
    const target = this.items.find((i) => i.id === targetItemId);
    const rune = this.items.find((i) => i.id === runeItemId && i.category === 'rune');
    if (!target || (target.category !== 'weapon' && target.category !== 'armor')) {
      return { ok: false, message: 'Выберите оружие или броню для вставки руны' };
    }
    if (!rune || rune.quantity <= 0) {
      return { ok: false, message: 'Рунический камень отсутствует' };
    }

    rune.quantity -= 1;
    target.socketedRuneId = rune.id;
    target.stats = {
      ...target.stats,
      attack: (target.stats?.attack ?? 0) + (rune.stats?.attack ?? 0),
      silverAttack: (target.stats?.silverAttack ?? 0) + (rune.stats?.silverAttack ?? 0),
      defense: (target.stats?.defense ?? 0) + (rune.stats?.defense ?? 0),
      signIntensity: (target.stats?.signIntensity ?? 0) + (rune.stats?.signIntensity ?? 0),
      runeEffect: rune.stats?.runeEffect,
    };

    if (rune.quantity <= 0) {
      this.items = this.items.filter((i) => i.id !== rune.id);
    }

    return {
      ok: true,
      message: `${rune.name} инкрустирована в «${target.name}»!`,
    };
  }

  public toggleEquip(itemId: string): { replacedItem?: GameItem } {
    const item = this.items.find((i) => i.id === itemId);
    if (!item) return {};
    if (
      item.category === 'weapon' ||
      item.category === 'armor' ||
      item.category === 'trophy'
    ) {
      if (item.equipped) {
        item.equipped = false;
        return {};
      } else {
        return this.equipItem(itemId);
      }
    }
    return {};
  }

  public upgradeItem(
    itemId: string,
    player: PlayerStats
  ): { ok: boolean; message: string } {
    const item = this.items.find((i) => i.id === itemId);
    if (!item || (item.category !== 'weapon' && item.category !== 'armor')) {
      return { ok: false, message: 'Этот предмет нельзя улучшить' };
    }

    const cost = getUpgradeCost(item);
    const ore = this.items.find((i) => i.id === 'iron_ore');
    const oreQty = ore?.quantity ?? 0;

    if (player.gold < cost.gold) {
      return { ok: false, message: `Недостаточно золота (нужно ${cost.gold})` };
    }
    if (oreQty < cost.oreCount) {
      return { ok: false, message: `Недостаточно железной руды (нужно ${cost.oreCount})` };
    }

    player.gold -= cost.gold;
    if (ore) ore.quantity -= cost.oreCount;
    item.upgradeLevel = (item.upgradeLevel ?? 0) + 1;

    return {
      ok: true,
      message: `${item.name} улучшен до ур. +${item.upgradeLevel}!`,
    };
  }

  public buyShopItem(
    shopItemId: string,
    player: PlayerStats,
    isFence = false
  ): { ok: boolean; message: string } {
    const shopItem = this.shopCatalog.find((i) => i.id === shopItemId);
    if (!shopItem) return { ok: false, message: 'Товар не найден' };
    const effectivePrice = calculateMerchantPrice(
      shopItem.value,
      player.reputation ?? 0,
      isFence
    );
    if (player.gold < effectivePrice) {
      return { ok: false, message: `Недостаточно золота (нужно ${effectivePrice} крон)` };
    }

    player.gold -= effectivePrice;
    const existing = this.items.find((i) => i.id === shopItem.id);
    if (existing) {
      existing.quantity += 1;
      if (shopItem.category === 'weapon' || shopItem.category === 'armor') {
        this.equipItem(existing.id);
      }
    } else {
      const slot = getItemEquipSlot(shopItem);
      this.items.push({
        ...shopItem,
        equipSlot: slot ?? undefined,
        quantity: 1,
        equipped: false,
      });
      if (shopItem.category === 'weapon' || shopItem.category === 'armor') {
        this.equipItem(shopItem.id);
      }
    }
    return {
      ok: true,
      message: `Куплено: ${shopItem.name} (${effectivePrice} крон)`,
    };
  }

  public sellInventoryItem(
    itemId: string,
    player: PlayerStats
  ): { ok: boolean; message: string } {
    const item = this.items.find((i) => i.id === itemId);
    if (!item || item.quantity <= 0) return { ok: false, message: 'Предмет отсутствует' };

    const sellPrice = Math.max(5, Math.round(item.value * 0.6));
    player.gold += sellPrice;
    item.quantity -= 1;
    if (item.quantity <= 0) {
      this.items = this.items.filter((i) => i.id !== itemId);
    }
    return { ok: true, message: `Продано: ${item.name} (+${sellPrice} золота)` };
  }

  public unlockSkill(skillId: string, player: PlayerStats): boolean {
    const skill = this.skills.find((s) => s.id === skillId);
    if (!skill || skill.level >= skill.maxLevel || player.skillPoints < skill.cost) {
      return false;
    }
    player.skillPoints -= skill.cost;
    skill.level += 1;
    return true;
  }
}
